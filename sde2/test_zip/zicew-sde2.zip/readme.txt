Readme

archive contains:

Readme.txt        : brief description of each file and the pledge.
which_shape.caml  : ocaml source file (Required functions).
zicew-sde2.log    : log of ouput of test cases.


Pledge:
On my honor I have neither given nor received aid on this exam.
SIGN Zice Wei.
