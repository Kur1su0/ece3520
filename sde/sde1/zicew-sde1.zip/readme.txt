Readme

archive contains:

Readme.txt      : brief description of each file and the pledge.
which_shape.pro : SWI-Prolog source file (Required predicates).
sde1.log        : log of ouput of test cases.


Pledge:
On my honor I have neither given nor received aid on this exam.
SIGN Zice Wei.
